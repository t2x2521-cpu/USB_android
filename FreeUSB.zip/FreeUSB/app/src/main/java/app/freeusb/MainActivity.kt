package app.freeusb

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import android.view.ViewGroup
import android.view.View
import me.jahnen.libaums.core.UsbMassStorageDevice
import me.jahnen.libaums.core.fs.FileSystem
import me.jahnen.libaums.core.fs.UsbFile
import me.jahnen.libaums.core.fs.UsbFileInputStream
import me.jahnen.libaums.core.fs.UsbFileOutputStream
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val PERM = "app.freeusb.PERM"
    private lateinit var status: TextView
    private lateinit var list: ListView
    private var device: UsbMassStorageDevice? = null
    private var fs: FileSystem? = null
    private var dir: UsbFile? = null
    private var items: List<UsbFile?> = emptyList()
    private var exporting: UsbFile? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { connect() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val row = LinearLayout(this)
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; setOnClickListener { a() }
            row.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        btn("Подключить") { connect() }
        btn("На флешку") { upload() }
        btn("Инфо") { info() }
        btn("Скорость") { bench() }
        status = TextView(this).apply { text = "Подключите флешку через OTG"; setPadding(0, 12, 0, 12) }
        list = ListView(this)
        root.addView(row); root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val f = IntentFilter(PERM)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, f)
        list.setOnItemClickListener { _, _, pos, _ ->
            val f2 = items[pos]
            if (f2 == null) { dir = dir?.parent; refresh() }
            else if (f2.isDirectory) { dir = f2; refresh() }
            else { exporting = f2; startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_TITLE, f2.name), 2) }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val f2 = items[pos] ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this).setMessage("Удалить ${f2.name}?")
                .setPositiveButton("Удалить") { _, _ -> io { f2.delete(); ui { refresh() } } }
                .setNegativeButton("Отмена", null).show()
            true
        }
        connect()
    }

    override fun onDestroy() { unregisterReceiver(receiver); device?.close(); super.onDestroy() }

    private fun ui(a: () -> Unit) = runOnUiThread(a)
    private fun io(a: () -> Unit) = thread { try { a() } catch (e: Exception) { ui { status.text = "Ошибка: ${e.message}" } } }
    private fun size(n: Long): String = when {
        n >= 1L shl 30 -> "%.1f ГБ".format(n / 1073741824.0)
        n >= 1L shl 20 -> "%.1f МБ".format(n / 1048576.0)
        else -> "%.1f КБ".format(n / 1024.0)
    }

    private fun connect() {
        val devs = UsbMassStorageDevice.getMassStorageDevices(this)
        if (devs.isEmpty()) { status.text = "Флешка не найдена"; return }
        val d = devs[0]
        val um = getSystemService(USB_SERVICE) as UsbManager
        if (!um.hasPermission(d.usbDevice)) {
            val pi = PendingIntent.getBroadcast(this, 0, Intent(PERM).setPackage(packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            um.requestPermission(d.usbDevice, pi); return
        }
        io {
            device?.close()
            d.init(); device = d
            fs = d.partitions[0].fileSystem
            dir = fs!!.rootDirectory
            ui { refresh() }
        }
    }

    private fun refresh() {
        val d = dir ?: return
        io {
            val l = d.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            val shown = (if (d.isRoot) emptyList() else listOf<UsbFile?>(null)) + l
            ui {
                items = shown
                list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, shown.map {
                    when { it == null -> "⬆ .."; it.isDirectory -> "📁 ${it.name}"; else -> "${it.name}  (${size(it.length)})" }
                })
                status.text = "${fs?.volumeLabel ?: "USB"}: ${d.absolutePath}  •  своб. ${size(fs?.freeSpace ?: 0)}"
            }
        }
    }

    private fun upload() {
        if (dir == null) { status.text = "Сначала подключите флешку"; return }
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 1)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        val uri: Uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (rc == 1) io {
            val name = contentResolver.query(uri, null, null, null, null)?.use {
                it.moveToFirst(); it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            } ?: "file"
            ui { status.text = "Копирование $name…" }
            val f = dir!!.createFile(name)
            contentResolver.openInputStream(uri)!!.use { i -> UsbFileOutputStream(f).use { o -> i.copyTo(o, 65536) } }
            ui { refresh() }
        } else if (rc == 2) io {
            val f = exporting!!
            ui { status.text = "Копирование ${f.name}…" }
            UsbFileInputStream(f).use { i -> contentResolver.openOutputStream(uri)!!.use { o -> i.copyTo(o, 65536) } }
            ui { status.text = "Готово: ${f.name}" }
        }
    }

    private fun info() {
        val d = device ?: return run { status.text = "Нет подключения" }
        val u = d.usbDevice
        val t = "Устройство: ${u.productName ?: "?"}\nПроизводитель: ${u.manufacturerName ?: "?"}\n" +
            "VID:PID  %04X:%04X\nМетка: ${fs?.volumeLabel}\nЕмкость: ${size(fs!!.capacity)}\nСвободно: ${size(fs!!.freeSpace)}\nРазделов: ${d.partitions.size}"
                .format(u.vendorId, u.productId)
        AlertDialog.Builder(this).setTitle("Инфо о флешке").setMessage(t).setPositiveButton("OK", null).show()
    }

    private fun bench() {
        val d = dir ?: return run { status.text = "Нет подключения" }
        io {
            val mb = 32; val buf = ByteArray(1 shl 20) { it.toByte() }
            ui { status.text = "Тест записи…" }
            val f = d.createFile("__bench.tmp")
            var t0 = System.nanoTime()
            UsbFileOutputStream(f).use { o -> repeat(mb) { o.write(buf) }; o.flush() }
            val w = mb / ((System.nanoTime() - t0) / 1e9)
            ui { status.text = "Тест чтения…" }
            t0 = System.nanoTime()
            UsbFileInputStream(f).use { i -> while (i.read(buf) > 0) { } }
            val r = mb / ((System.nanoTime() - t0) / 1e9)
            f.delete()
            ui { status.text = "Запись %.1f МБ/с • Чтение %.1f МБ/с".format(w, r); refresh() }
        }
    }
}
