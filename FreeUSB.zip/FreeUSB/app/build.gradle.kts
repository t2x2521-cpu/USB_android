plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "app.freeusb"
    compileSdk = 34
    defaultConfig { applicationId = "app.freeusb"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "0.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("me.jahnen.libaums:core:0.10.0") }
